package com.mycompany.mychatapp;

import java.util.Scanner;
import javax.swing.JOptionPane;

public class MyChatApp {

    // Single shared Scanner instance for all user input throughout the app
    private static Scanner input = new Scanner(System.in);

    
    private static String readLine(String prompt) {
        String line = "";

        // Keep asking until the user enters something that is not blank
        while (line.isEmpty()) {
            System.out.print(prompt);
            line = input.nextLine().trim(); // Read and trim whitespace

            // If still empty after trimming, warn and loop again
            if (line.isEmpty()) {
                System.out.println("This field cannot be empty. Please try again.");
            }
        }

        return line;
    }

    public static void main(String[] args) {

        // Create an instance of Login to access validation and auth methods
        Login objLogin = new Login();

        //REGISTRATION

        System.out.println("=== MYCHATAPP REGISTRATION ===\n");

        // Collect name and surname - readLine() ensures they are not empty
        String name    = readLine("Enter your name: ");
        String surname = readLine("Enter your surname: ");

        // Loop until a valid username is entered
        String username;
        while (true) {
            username = readLine("Create a username (max 5 chars, must contain _ ): ");
            if (objLogin.checkUserName(username)) break; // Valid — exit loop
            System.out.println("Username invalid: must be 5 characters or less and contain '_'. Try again.");
        }

        // Loop until a valid password is entered
        String password;
        while (true) {
            password = readLine("Create a password (8+ chars, uppercase, number, special): ");
            if (objLogin.checkPasswordComplexity(password)) break; // Valid — exit loop
            System.out.println("Password invalid: must be 8+ chars, include an uppercase letter, a number, and a special character. Try again.");
        }

        // Loop until a valid phone number is entered
        String phone;
        while (true) {
            phone = readLine("Enter cell number (+27 followed by 9 digits): ");
            if (objLogin.checkCellPhoneNumber(phone)) break; // Valid — exit loop
            System.out.println("Phone invalid: must start with +27 and be followed by exactly 9 digits. Try again.");
        }

        // All registration fields are valid — confirm to the user
        System.out.println("\nRegistration successful!");
        System.out.println("Welcome, " + name + " " + surname + "!\n");

        //LOGIN

        System.out.println("=== LOGIN ===\n");

        // Keep looping until the user logs in successfully or chooses to quit
        while (true) {

            // Collect login credentials — readLine() ensures they are not empty
            String loginUser = readLine("Enter username: ");
            String loginPass = readLine("Enter password: ");

            // Get specific feedback on whether login succeeded or which field failed
            String feedback = objLogin.loginFeedback(loginUser, loginPass, username, password);
            System.out.println("\n" + feedback + "\n");

            // If login was successful, call Message menu
            if (feedback.equals("Login successful!")) {
       Message.showMenu(name, surname);
       break;
   }

            // Login failed — ask if the user wants to try again
            System.out.print("Try again? (yes/no): ");
            String retry = input.nextLine().trim(); // Read retry choice directly from Scanner

            if (!retry.equalsIgnoreCase("yes")) {
                System.out.println("Goodbye!");
                break;
            }

            // close loop
            System.out.println();
        }

        // Close the Scanner when the application is done
        input.close();
    }
}
