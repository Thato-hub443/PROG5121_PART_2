package com.mycompany.mychatapp; // Declares the package this class belongs to

import java.util.ArrayList; // Imports ArrayList for dynamic list storage
import javax.swing.*; // Imports all Swing GUI components (JFrame, JPanel, JButton, etc.)
import java.awt.*; // Imports AWT layout managers and graphics utilities
import java.awt.event.ActionEvent; // Imports ActionEvent used for button action handling

public class Message extends JFrame { // Declares the Message class, extending JFrame to create a window
    
    // Data storage
    private static ArrayList<String> msgID = new ArrayList<>(); // Stores unique IDs for each message
    private static ArrayList<String> phoneNum = new ArrayList<>(); // Stores recipient phone numbers
    private static ArrayList<String> content = new ArrayList<>(); // Stores message text content
    private static ArrayList<String> hashCode = new ArrayList<>(); // Stores computed hash codes per message
    private static int idTracker = 1000; // Starting value for auto-incrementing message IDs
    
    // GUI Components
    private JPanel mainPanel; // The root panel that holds all sub-panels via CardLayout
    private JPanel menuPanel; // Panel displaying the main navigation menu
    private JPanel composePanel; // Panel for composing a new message
    private JPanel historyPanel; // Panel for viewing message history
    private JTextArea displayArea; // Text area used to display message history
    private JTextField phoneField; // Input field for the recipient's phone number
    private JTextArea messageArea; // Input area for the message body
    
    private String currentUser = ""; // Stores the first name of the logged-in user
    private String currentSurname = ""; // Stores the surname of the logged-in user
    
    
    // ========== VALIDATION METHODS ==========
    
    private static boolean validatePhoneFormat(String phone) { // Validates that a phone number meets format requirements
        if (phone == null || phone.isEmpty()) return false; // Rejects null or empty input
        if (!phone.startsWith("+")) return false; // Rejects numbers not starting with a "+" prefix
        return phone.length() >= 12 && phone.length() <= 12; // Accepts only exactly 12-character numbers (e.g. +27XXXXXXXXX)
    }
    
    
    private static boolean validateMsgLength(String msg) { // Validates that a message is within the allowed character range
        return msg != null && msg.length() > 0 && msg.length() <= 250; // Returns true only for non-null messages between 1 and 250 characters
    }
    
    
    // ========== UTILITY METHODS ==========
    
    private static String makeID() { // Generates a new unique message ID by incrementing the tracker
        return String.valueOf(++idTracker); // Pre-increments idTracker and returns it as a String
    }
    
    
    private static String makeHash(String id, int num, String msg) { // Creates a hash string based on message ID, count, and content
        String[] msgWords = msg.trim().split("\\s+"); // Splits the message into individual words after trimming whitespace
        String start = id.substring(0, Math.min(2, id.length())); // Takes the first 2 characters of the ID (or fewer if ID is shorter)
        String first = msgWords.length > 0 ? msgWords[0] : "EMPTY"; // Gets the first word of the message, or "EMPTY" if none
        String last = msgWords.length > 0 ? msgWords[msgWords.length - 1] : "EMPTY"; // Gets the last word of the message, or "EMPTY" if none
        
        return (start + ":" + num + ":" + first + ":" + last).toUpperCase(); // Combines parts into a colon-separated hash and uppercases it
    }
    
    
    private static int getMessageCount() { // Returns the total number of messages stored
        return msgID.size(); // Uses the size of the msgID list as the message count
    }
    
    
    // ========== GUI SETUP ==========
    
    public Message() { // Constructor that initialises and displays the main application window
        setTitle("QuickChat - Message System"); // Sets the window title bar text
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Exits the application when the window is closed
        setSize(600, 500); // Sets the window dimensions to 600x500 pixels
        setLocationRelativeTo(null); // Centers the window on the screen
        setResizable(false); // Prevents the user from resizing the window
        
        mainPanel = new JPanel(new CardLayout()); // Creates the main panel with CardLayout for panel switching
        createMenuPanel(); // Builds and assigns the menu panel
        createComposePanel(); // Builds and assigns the compose panel
        createHistoryPanel(); // Builds and assigns the history panel
        
        mainPanel.add(menuPanel, "MENU"); // Registers the menu panel under the key "MENU"
        mainPanel.add(composePanel, "COMPOSE"); // Registers the compose panel under the key "COMPOSE"
        mainPanel.add(historyPanel, "HISTORY"); // Registers the history panel under the key "HISTORY"
        
        add(mainPanel); // Adds the main panel to the JFrame's content area
        setVisible(true); // Makes the window visible on screen
    }
    
    
    // ========== MENU PANEL ==========
    
    private void createMenuPanel() { // Builds the main navigation menu panel
        menuPanel = new JPanel(); // Creates a new JPanel for the menu
        menuPanel.setBackground(new Color(45, 45, 45)); // Sets a dark grey background colour
        menuPanel.setLayout(new BoxLayout(menuPanel, BoxLayout.Y_AXIS)); // Stacks child components vertically
        menuPanel.setBorder(BorderFactory.createEmptyBorder(50, 100, 50, 100)); // Adds padding around the panel contents
        
        // Title
        JLabel titleLabel = new JLabel("QuickChat"); // Creates the application title label
        titleLabel.setFont(new Font("Arial", Font.BOLD, 36)); // Sets a large bold font for the title
        titleLabel.setForeground(Color.WHITE); // Makes the title text white
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT); // Centers the label horizontally
        menuPanel.add(titleLabel); // Adds the title label to the menu panel
        
        // Subtitle
        JLabel userLabel = new JLabel("Welcome, " + currentUser + " " + currentSurname); // Creates a personalised welcome label
        userLabel.setFont(new Font("Arial", Font.PLAIN, 14)); // Sets a smaller plain font for the subtitle
        userLabel.setForeground(new Color(200, 200, 200)); // Sets a light grey colour for the subtitle text
        userLabel.setAlignmentX(Component.CENTER_ALIGNMENT); // Centers the label horizontally
        menuPanel.add(Box.createVerticalStrut(10)); // Adds 10px vertical spacing above the welcome label
        menuPanel.add(userLabel); // Adds the welcome label to the menu panel
        
        menuPanel.add(Box.createVerticalStrut(40)); // Adds 40px vertical spacing before the buttons
        
        // Buttons
        JButton composeBtn = createStyledButton("📤 Compose Message"); // Creates a styled button for composing messages
        composeBtn.addActionListener(e -> showPanel("COMPOSE")); // Switches to the compose panel when clicked
        menuPanel.add(composeBtn); // Adds the compose button to the menu panel
        
        menuPanel.add(Box.createVerticalStrut(15)); // Adds 15px spacing between buttons
        
        JButton historyBtn = createStyledButton("📋 View History"); // Creates a styled button for viewing message history
        historyBtn.addActionListener(e -> showPanel("HISTORY")); // Switches to the history panel when clicked
        menuPanel.add(historyBtn); // Adds the history button to the menu panel
        
        menuPanel.add(Box.createVerticalStrut(15)); // Adds 15px spacing between buttons
        
        JButton exitBtn = createStyledButton("🚪 Exit"); // Creates a styled button to exit the application
        exitBtn.setBackground(new Color(200, 50, 50)); // Overrides the button background to red to signal exit
        exitBtn.addActionListener(e -> { // Adds a click listener to handle the exit action
            JOptionPane.showMessageDialog(this, "Goodbye!"); // Shows a farewell dialog before exiting
            System.exit(0); // Terminates the application
        });
        menuPanel.add(exitBtn); // Adds the exit button to the menu panel
    }
    
    
    // ========== COMPOSE PANEL ==========
    
    private void createComposePanel() { // Builds the message composition panel
        composePanel = new JPanel(); // Creates a new JPanel for composing messages
        composePanel.setBackground(new Color(240, 240, 240)); // Sets a light grey background
        composePanel.setLayout(new BoxLayout(composePanel, BoxLayout.Y_AXIS)); // Stacks child components vertically
        composePanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20)); // Adds uniform padding around the panel
        
        // Title
        JLabel titleLabel = new JLabel("Compose New Message"); // Creates a heading label for this panel
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18)); // Sets a bold medium font for the heading
        composePanel.add(titleLabel); // Adds the heading to the panel
        composePanel.add(Box.createVerticalStrut(15)); // Adds 15px spacing below the heading
        
        // Phone input
        JLabel phoneLabel = new JLabel("Recipient Phone Number:"); // Creates a label for the phone input field
        phoneLabel.setFont(new Font("Arial", Font.PLAIN, 12)); // Sets a small plain font for the label
        composePanel.add(phoneLabel); // Adds the phone label to the panel
        
        phoneField = new JTextField(); // Creates the text field for entering a phone number
        phoneField.setFont(new Font("Arial", Font.PLAIN, 12)); // Sets the font for the phone input field
        phoneField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30)); // Limits the field height to 30px while allowing full width
        phoneField.setText("+27"); // Pre-fills the field with the South African dialling code
        composePanel.add(phoneField); // Adds the phone field to the panel
        composePanel.add(Box.createVerticalStrut(15)); // Adds 15px spacing after the phone field
        
        // Message input
        JLabel msgLabel = new JLabel("Message (Max 250 characters):"); // Creates a label for the message input area
        msgLabel.setFont(new Font("Arial", Font.PLAIN, 12)); // Sets a small plain font for the label
        composePanel.add(msgLabel); // Adds the message label to the panel
        
        messageArea = new JTextArea(8, 40); // Creates a multi-line text area with 8 rows and 40 columns
        messageArea.setFont(new Font("Arial", Font.PLAIN, 12)); // Sets the font for the message input area
        messageArea.setLineWrap(true); // Enables line wrapping so text doesn't overflow horizontally
        messageArea.setWrapStyleWord(true); // Wraps at word boundaries rather than mid-word
        JScrollPane scrollPane = new JScrollPane(messageArea); // Wraps the text area in a scroll pane for overflow
        scrollPane.setMaximumSize(new Dimension(Integer.MAX_VALUE, 150)); // Limits the scroll pane height to 150px
        composePanel.add(scrollPane); // Adds the scrollable message area to the panel
        composePanel.add(Box.createVerticalStrut(15)); // Adds 15px spacing after the message area
        
        // Character counter
        JLabel charLabel = new JLabel("Characters: 0/250"); // Creates a live character count display label
        charLabel.setFont(new Font("Arial", Font.PLAIN, 10)); // Sets a small font for the counter
        messageArea.addKeyListener(new java.awt.event.KeyAdapter() { // Attaches a key listener to update the counter on each keystroke
            public void keyReleased(java.awt.event.KeyEvent evt) { // Fires after each key is released
                charLabel.setText("Characters: " + messageArea.getText().length() + "/250"); // Updates the counter with the current character count
            }
        });
        composePanel.add(charLabel); // Adds the character counter label to the panel
        composePanel.add(Box.createVerticalStrut(15)); // Adds 15px spacing after the counter
        
        // Button panel
        JPanel buttonPanel = new JPanel(); // Creates a sub-panel to hold the action buttons
        buttonPanel.setBackground(new Color(240, 240, 240)); // Matches the compose panel background colour
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 0)); // Lays buttons out in a centered row with 10px horizontal gaps
        
        JButton sendBtn = new JButton("✓ Send"); // Creates the Send button
        sendBtn.setBackground(new Color(50, 150, 50)); // Sets a green background for the Send button
        sendBtn.setForeground(Color.WHITE); // Sets white text on the Send button
        sendBtn.setFont(new Font("Arial", Font.BOLD, 12)); // Sets a bold font for the Send button label
        sendBtn.addActionListener(e -> sendMessage()); // Calls sendMessage() when the Send button is clicked
        buttonPanel.add(sendBtn); // Adds the Send button to the button panel
        
        JButton saveBtn = new JButton("⧗ Save"); // Creates the Save button
        saveBtn.setBackground(new Color(100, 150, 200)); // Sets a blue background for the Save button
        saveBtn.setForeground(Color.WHITE); // Sets white text on the Save button
        saveBtn.setFont(new Font("Arial", Font.BOLD, 12)); // Sets a bold font for the Save button label
        saveBtn.addActionListener(e -> saveMessage()); // Calls saveMessage() when the Save button is clicked
        buttonPanel.add(saveBtn); // Adds the Save button to the button panel
        
        JButton backBtn = new JButton("← Back"); // Creates the Back navigation button
        backBtn.setBackground(new Color(150, 150, 150)); // Sets a grey background for the Back button
        backBtn.setForeground(Color.WHITE); // Sets white text on the Back button
        backBtn.setFont(new Font("Arial", Font.BOLD, 12)); // Sets a bold font for the Back button label
        backBtn.addActionListener(e -> { // Adds a click listener to navigate back to the menu
            phoneField.setText("+27"); // Resets the phone field to the default dialling code
            messageArea.setText(""); // Clears the message input area
            showPanel("MENU"); // Switches the visible panel back to the main menu
        });
        buttonPanel.add(backBtn); // Adds the Back button to the button panel
        
        composePanel.add(buttonPanel); // Adds the button panel to the compose panel
        composePanel.add(Box.createVerticalGlue()); // Pushes all content to the top by filling remaining vertical space
    }
    
    
    // ========== HISTORY PANEL ==========
    
    private void createHistoryPanel() { // Builds the message history viewing panel
        historyPanel = new JPanel(); // Creates a new JPanel for the history view
        historyPanel.setBackground(new Color(240, 240, 240)); // Sets a light grey background
        historyPanel.setLayout(new BorderLayout(10, 10)); // Uses BorderLayout with 10px horizontal and vertical gaps
        historyPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20)); // Adds uniform padding around the panel
        
        // Title
        JLabel titleLabel = new JLabel("Message History"); // Creates a heading label for this panel
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18)); // Sets a bold medium font for the heading
        historyPanel.add(titleLabel, BorderLayout.NORTH); // Places the heading at the top of the panel
        
        // Display area
        displayArea = new JTextArea(); // Creates the text area where message history is rendered
        displayArea.setEditable(false); // Makes the history display read-only
        displayArea.setFont(new Font("Courier New", Font.PLAIN, 11)); // Uses a monospaced font for consistent history formatting
        displayArea.setBackground(Color.WHITE); // Sets a white background for the display area
        JScrollPane scrollPane = new JScrollPane(displayArea); // Wraps the display area in a scroll pane for long histories
        historyPanel.add(scrollPane, BorderLayout.CENTER); // Places the scrollable display in the center of the panel
        
        // Button panel
        JPanel buttonPanel = new JPanel(); // Creates a sub-panel to hold the action buttons
        buttonPanel.setBackground(new Color(240, 240, 240)); // Matches the history panel background colour
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 0)); // Centers the buttons with 10px horizontal gaps
        
        JButton refreshBtn = new JButton("🔄 Refresh"); // Creates a Refresh button to reload the history display
        refreshBtn.addActionListener(e -> displayHistory()); // Calls displayHistory() when Refresh is clicked
        buttonPanel.add(refreshBtn); // Adds the Refresh button to the button panel
        
        JButton backBtn = new JButton("← Back"); // Creates the Back navigation button
        backBtn.addActionListener(e -> showPanel("MENU")); // Switches back to the main menu when clicked
        buttonPanel.add(backBtn); // Adds the Back button to the button panel
        
        historyPanel.add(buttonPanel, BorderLayout.SOUTH); // Places the button panel at the bottom of the history panel
    }
    
    
    // ========== ACTION METHODS ==========
    
    private void sendMessage() { // Handles the logic for validating and sending a message
        String phone = phoneField.getText().trim(); // Reads and trims whitespace from the phone field input
        String msg = messageArea.getText().trim(); // Reads and trims whitespace from the message input area
        
        if (!validatePhoneFormat(phone)) { // Checks whether the phone number passes format validation
            JOptionPane.showMessageDialog(this, // Shows an error dialog anchored to this window
                    "Invalid phone format.\nFormat: +27 followed by 9 digits", // Error message body
                    "Validation Error", JOptionPane.WARNING_MESSAGE); // Dialog title and icon type
            return; // Stops execution if validation fails
        }
        
        if (!validateMsgLength(msg)) { // Checks whether the message length is within the allowed range
            JOptionPane.showMessageDialog(this, // Shows an error dialog anchored to this window
                    "Message must be 1-250 characters", // Error message body
                    "Validation Error", JOptionPane.WARNING_MESSAGE); // Dialog title and icon type
            return; // Stops execution if validation fails
        }
        
        String newID = makeID(); // Generates a new unique message ID
        int count = getMessageCount() + 1; // Calculates the position of this message in the list (1-based)
        String hash = makeHash(newID, count, msg); // Generates a hash string for this message
        
        msgID.add(newID); // Stores the new message ID in the list
        phoneNum.add(phone); // Stores the recipient phone number in the list
        content.add(msg); // Stores the message text in the list
        hashCode.add(hash); // Stores the computed hash in the list
        
        JOptionPane.showMessageDialog(this, // Shows a success dialog anchored to this window
                "✓ Message Sent!\n\nID: " + newID + "\nHash: " + hash, // Success message showing the ID and hash
                "Success", JOptionPane.INFORMATION_MESSAGE); // Dialog title and icon type
        
        phoneField.setText("+27"); // Resets the phone field to the default dialling code
        messageArea.setText(""); // Clears the message input area after sending
    }
    
    
    private void saveMessage() { // Handles the logic for validating and saving a message without sending
        String phone = phoneField.getText().trim(); // Reads and trims whitespace from the phone field input
        String msg = messageArea.getText().trim(); // Reads and trims whitespace from the message input area
        
        if (!validatePhoneFormat(phone)) { // Checks whether the phone number passes format validation
            JOptionPane.showMessageDialog(this, // Shows an error dialog anchored to this window
                    "Invalid phone format.\nFormat: +27 followed by 9 digits", // Error message body
                    "Validation Error", JOptionPane.WARNING_MESSAGE); // Dialog title and icon type
            return; // Stops execution if validation fails
        }
        
        if (!validateMsgLength(msg)) { // Checks whether the message length is within the allowed range
            JOptionPane.showMessageDialog(this, // Shows an error dialog anchored to this window
                    "Message must be 1-250 characters", // Error message body
                    "Validation Error", JOptionPane.WARNING_MESSAGE); // Dialog title and icon type
            return; // Stops execution if validation fails
        }
        
        String newID = makeID(); // Generates a new unique message ID
        int count = getMessageCount() + 1; // Calculates the position of this message in the list (1-based)
        String hash = makeHash(newID, count, msg); // Generates a hash string for this message
        
        msgID.add(newID); // Stores the new message ID in the list
        phoneNum.add(phone); // Stores the recipient phone number in the list
        content.add(msg); // Stores the message text in the list
        hashCode.add(hash); // Stores the computed hash in the list
        
        JOptionPane.showMessageDialog(this, // Shows a success dialog anchored to this window
                "⧗ Message Saved!\n\nID: " + newID + "\nHash: " + hash, // Success message showing the ID and hash
                "Success", JOptionPane.INFORMATION_MESSAGE); // Dialog title and icon type
        
        phoneField.setText("+27"); // Resets the phone field to the default dialling code
        messageArea.setText(""); // Clears the message input area after saving
    }
    
    
    private void displayHistory() { // Builds and displays the full message history in the display area
        if (msgID.isEmpty()) { // Checks if there are any messages stored
            displayArea.setText("No messages yet."); // Shows a placeholder if the history is empty
            return; // Exits early since there is nothing to display
        }
        
        StringBuilder history = new StringBuilder(); // Creates a StringBuilder to efficiently build the history string
        history.append("           MESSAGE HISTORY\n"); // Appends a centred heading to the history output
        
        
        for (int i = 0; i < msgID.size(); i++) { // Iterates over all stored messages by index
            history.append("[").append(i + 1).append("]\n"); // Appends the 1-based message number
            history.append("ID: ").append(msgID.get(i)).append("\n"); // Appends the message ID
            history.append("Hash: ").append(hashCode.get(i)).append("\n"); // Appends the message hash
            history.append("To: ").append(phoneNum.get(i)).append("\n"); // Appends the recipient phone number
            history.append("Message: ").append(content.get(i)).append("\n"); // Appends the message content
        }
        

        history.append("Total: ").append(getMessageCount()).append(" message(s)\n"); // Appends the total message count at the end

        
        displayArea.setText(history.toString()); // Sets the completed history string as the display area text
        displayArea.setCaretPosition(0); // Scrolls the display area back to the top
    }
    
    
    private void showPanel(String panelName) { // Switches the visible panel in the CardLayout
        CardLayout cl = (CardLayout) mainPanel.getLayout(); // Retrieves the CardLayout manager from the main panel
        cl.show(mainPanel, panelName); // Shows the panel registered under the given key name
        
        if (panelName.equals("HISTORY")) { // Checks if the panel being shown is the history panel
            displayHistory(); // Automatically refreshes the history display when navigating to it
        }
    }
    
    
    // ========== HELPER METHOD ==========
    
    private JButton createStyledButton(String text) { // Creates a consistently styled navigation button
        JButton btn = new JButton(text); // Creates a new button with the given label text
        btn.setFont(new Font("Arial", Font.BOLD, 14)); // Sets a bold 14pt font for the button label
        btn.setBackground(new Color(70, 130, 180)); // Sets a steel-blue background colour
        btn.setForeground(Color.WHITE); // Sets white text on the button
        btn.setFocusPainted(false); // Removes the focus border drawn when the button is selected via keyboard
        btn.setAlignmentX(Component.CENTER_ALIGNMENT); // Centers the button horizontally within its parent
        btn.setMaximumSize(new Dimension(300, 50)); // Caps the button size at 300x50px
        btn.setMinimumSize(new Dimension(300, 50)); // Ensures the button is never smaller than 300x50px
        btn.setPreferredSize(new Dimension(300, 50)); // Sets the preferred size to 300x50px for consistent layout
        return btn; // Returns the fully configured button
    }
    
    
    // ========== STATIC METHOD FOR INTEGRATION ==========
    
    public static void showMenu(String userName, String userSurname) { // Static entry point to launch the GUI with a specific user's details
        SwingUtilities.invokeLater(() -> { // Schedules GUI creation on the Event Dispatch Thread for thread safety
            Message frame = new Message(); // Creates a new instance of the Message window
            frame.currentUser = userName; // Sets the logged-in user's first name on the frame instance
            frame.currentSurname = userSurname; // Sets the logged-in user's surname on the frame instance
            
            // Update menu panel with user name
            JLabel userLabel = (JLabel) frame.menuPanel.getComponent(2); // Retrieves the welcome label by its component index in the menu panel
            userLabel.setText("Welcome, " + userName + " " + userSurname); // Updates the welcome label text with the user's full name
        });
    }
}