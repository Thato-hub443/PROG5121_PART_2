package com.mycompany.mychatapp;

public class Login {

    //Checks if the username meets the required format:
    public boolean checkUserName(String username) {
        return username.length() <= 5 && username.contains("_");
    }

    //Checks if the password meets complexity requirements:
    public boolean checkPasswordComplexity(String password) {
        boolean hasLength    = password.length() >= 8;               // Must be 8+ chars
        boolean hasUppercase = password.matches(".*[A-Z].*");        // Must have uppercase
        boolean hasNumbers   = password.matches(".*[0-9].*");        // Must have a digit
        boolean hasSpecial   = !password.matches("[A-Za-z0-9]*");    // Must have special char
        return hasLength && hasUppercase && hasNumbers && hasSpecial;
    }

    //Checks if the cell phone number is valid:
    public boolean checkCellPhoneNumber(String number) {
    return number.length() == 12 && number.startsWith("+27");
}

    //Attempts to register a user by validating all provided fields
    public String registerUser(String username, String password, String phone) {
        // Check that no fields are empty before doing any other validation
        if (username.isEmpty() || password.isEmpty() || phone.isEmpty()) {
            return "Error: All fields are required!";
        }

        // Validate username format
        if (!checkUserName(username)) {
            return "Username invalid: must be 5 chars or less and contain _";
        }

        // Validate password complexity
        if (!checkPasswordComplexity(password)) {
            return "Password invalid: 8+ chars, uppercase, number, special char";
        }

        // Validate phone number format
        if (!checkCellPhoneNumber(phone)) {
            return "Phone invalid: +27 followed by 15 digits";
        }

        // All validations passed
        return "Registration successful!";
    }

    //Checks if the entered login credentials match the stored credentials.
    public boolean loginUser(String enteredUsername, String enteredPassword,
                             String storedUsername, String storedPassword) {
        return enteredUsername.equals(storedUsername)
                && enteredPassword.equals(storedPassword);
    }

    
    public String loginFeedback(String enteredUsername, String enteredPassword,
                                String storedUsername, String storedPassword) {
        // Both username and password are wrong
        if (!enteredUsername.equals(storedUsername) && !enteredPassword.equals(storedPassword)) {
            return "Login failed: Both username anrtbmrtd password are incorrect.";
        }

        // Only the username is wrong
        if (!enteredUsername.equals(storedUsername)) {
            return "Login failed: Username is incorrect.";
        }

        // Only the password is wrong
        if (!enteredPassword.equals(storedPassword)) {
            return "Login failed: Password is incorrect.";
        }

        // Both match — login successful
        return "Login successful!";
    }
}